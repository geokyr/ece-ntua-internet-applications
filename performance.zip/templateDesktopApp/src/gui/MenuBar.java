package gui;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;

import java.util.Date;
import java.util.Scanner;

public class MenuBar extends JMenuBar {
    
    JMenu menu1, menu2;
    JMenuItem itemOne, itemTwo, itemThree;
    JMenuItem itemFour, itemFive, itemSix;
    
    MenuItemHandler handler;

    
    public MenuBar() {
    	
 	    this.handler = new MenuItemHandler();

         menu1 = new JMenu("First menu");
         menu2 = new JMenu("Second menu");

        //Item 1 of Menu 1 - itemOne
	    itemOne = new JMenuItem("Item One");					// Create menu item
	    itemOne.addActionListener(handler);						// Add listener to the menu item
	    menu1.add(itemOne);									// Add the menu item to the menu

        //Item 2 of Menu 1 - itemTwo
        itemTwo = new JMenuItem("Item Two");					// Create menu item
        itemTwo.addActionListener(handler);						// Add listener to the menu item
        menu1.add(itemTwo);									// Add the menu item to the menu

        //Item 3 of Menu 1 - itemThree
        itemThree = new JMenuItem("Item Three");					// Create menu item
        itemThree.addActionListener(handler);						// Add listener to the menu item
        menu1.add(itemThree);									// Add the menu item to the menu

        //Item 1 of Menu 2 - itemFour
        itemFour = new JMenuItem("Item Four");					// Create menu item
        itemFour.addActionListener(handler);						// Add listener to the menu item
        menu2.add(itemFour);									// Add the menu item to the menu

        //Item 2 of Menu 2 - itemFive
        itemFive = new JMenuItem("Item Five");					// Create menu item
        itemFive.addActionListener(handler);						// Add listener to the menu item
        menu2.add(itemFive);									// Add the menu item to the menu

        //Item 3 of Menu 2 - itemSix
        itemSix = new JMenuItem("Item Six");						// Create menu item
        itemSix.addActionListener(handler);						// Add listener to the menu item
        menu2.add(itemSix);										// Add the menu item to the menu

        this.add(menu1);										// Add the menu to the menu bar
        this.add(menu2);										// Add the menu to the menu bar


    }

    	class MenuItemHandler implements ActionListener, Serializable {
		
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource() == itemOne) {
                System.out.println("Item One");
			}
            else if(e.getSource() == itemTwo){
                System.out.println("Item Two");
            }
            else if(e.getSource() == itemThree){
                System.out.println("Item Three");
            }
            else if(e.getSource() == itemFour){
                System.out.println("Item Four");
            }
            else if(e.getSource() == itemFive){
                System.out.println("Item Five");
            }
            else if(e.getSource() == itemSix){
                System.out.println("Item Six");
            }
			
			
			
		}
	
	}
	
    
}




