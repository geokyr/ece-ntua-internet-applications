package jsonCookies;

import org.json.Cookie;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

public class JSONCookies {
	
	public static void main(String[] args) throws JSONException {
		
		String cookies = "username = Mark Den; expires = Thu, 15 Jun 2020 12:00:00 UTC; path = /";
		//Case 1: Converts Cookie String to JSONObject
		JSONObject jsonObject = Cookie.toJSONObject(cookies);
		System.out.println(jsonObject);
		
		//Case 2: Converts JSONObject to Cookie String
		System.out.println(Cookie.toString(jsonObject));
		
		String json_data = "{\"student\":{\"name\":\"Neeraj Mishra\", \"age\":\"22\"}}";
		JSONObject obj = new JSONObject(json_data);
		//Case 3: Converts JSON to XML
		String xml_data = XML.toString(obj);
		System.out.println(xml_data);
		
		String xml_data1 = "<student><name>Neeraj Mishra</name><age>22</age></student>";
		//Case 4: Converts XML to JSON
		JSONObject obj1 = XML.toJSONObject(xml_data1);
		System.out.println(obj1.toString());
		
	}

}
